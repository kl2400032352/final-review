# Student Project Management System Backend

This is the backend API for the Student Project Management System. It is built with Node.js, Express, and MongoDB.

## Features
- User authentication (JWT)
- Admin and student roles
- Project, task, milestone, and submission management
- RESTful API endpoints

## Getting Started

### 0. Use Node 22 (recommended)
This project is pinned to Node 22 via `.nvmrc`.

```bash
nvm install
nvm use
node -v
```

### 1. Install dependencies
```
npm install
```

### 2. Set up environment variables
Edit `.env`:
```
MONGO_URI=mongodb://localhost:27017/student_project_management
JWT_SECRET=supersecretkey
PORT=5002
```

### 3. Start the server
```
npm run dev
```

The API will be available at `http://localhost:5002`.

## Folder Structure
- `controllers/` — Business logic for each resource
- `models/` — Mongoose schemas
- `routes/` — Express route definitions
- `middleware/` — Custom middleware (e.g., auth)
- `config/` — Database connection

## API Endpoints
See the code for all available endpoints. Main routes:
- `/api/auth` — Signup, login
- `/api/users` — User info
- `/api/projects` — Project CRUD, assign, tasks
- `/api/submissions` — File submissions

## Connect to Frontend
- Use the endpoints above from your React frontend
- Send JWT in `Authorization: Bearer <token>` header for protected routes

---

**Ready for integration with your Vite + React frontend!**
